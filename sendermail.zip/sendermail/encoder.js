"use strict";

// ============================================================
//   ENCODEUR HTML - Délivrabilité maximale
//   Appliqué à chaque email individuellement
// ============================================================

const ZERO_WIDTH = ['\u200b', '\u200c', '\u200d', '\u2060', '\ufeff'];
const COMMENT_POOL = [
	'<!-- ok -->', '<!-- x -->', '<!-- . -->', '<!---->',
	'<!-- a -->', '<!-- _ -->', '<!-- i -->', '<!-- 1 -->'
];

// 🔡 Encode une URL en HTML entities mélangées (cache aux scanners)
function encodeUrl(url) {
	let result = '';
	for (let i = 0; i < url.length; i++) {
		const char = url[i];
		const r = Math.random();
		if (r < 0.30 && char.match(/[a-zA-Z0-9]/)) {
			// Entity décimale
			result += `&#${char.charCodeAt(0)};`;
		} else if (r < 0.50 && char.match(/[a-zA-Z0-9]/)) {
			// Entity hex
			result += `&#x${char.charCodeAt(0).toString(16)};`;
		} else {
			result += char;
		}
	}
	return result;
}

// 🔡 Encode du texte visible avec entities + zero-width légers
function encodeVisibleText(text) {
	// On ne touche pas aux placeholders ##tag##
	if (text.includes('##')) return text;

	let result = '';
	for (let i = 0; i < text.length; i++) {
		const char = text[i];
		const code = char.charCodeAt(0);

		// Injecte zero-width occasionnellement
		if (Math.random() < 0.12 && char !== ' ') {
			result += ZERO_WIDTH[Math.floor(Math.random() * ZERO_WIDTH.length)];
		}

		// Encode quelques caractères en entities
		if (Math.random() < 0.20 && code > 31 && code < 127 && char.match(/[a-zA-Z]/)) {
			result += `&#${code};`;
		} else {
			result += char;
		}
	}
	return result;
}

// 💬 Insère des commentaires HTML invisibles aléatoires entre les tags
function injectComments(html) {
	// Insère entre les balises fermantes et ouvrantes
	return html.replace(/(<\/(?:p|td|tr|div|span|h[1-6])>)/gi, (match) => {
		if (Math.random() < 0.35) {
			const comment = COMMENT_POOL[Math.floor(Math.random() * COMMENT_POOL.length)];
			return match + comment;
		}
		return match;
	});
}

// 🔗 Encode les attributs href des liens
function encodeHrefs(html) {
	return html.replace(/href="([^"]+)"/gi, (match, url) => {
		// Ne pas encoder les placeholders
		if (url.startsWith('##') || url.startsWith('mailto:')) return match;
		const encoded = encodeUrl(url);
		return `href="${encoded}"`;
	});
}

// 📝 Fragmente le texte visible avec des <span> vides aléatoires
function fragmentText(html) {
	// Appliqué uniquement sur les blocs de texte dans <p> et <td>
	return html.replace(/>([^<]{15,})</g, (match, text) => {
		// Ignore si ça contient des balises ou des placeholders
		if (text.includes('<') || text.includes('>') || text.includes('##')) return match;

		const words = text.split(' ');
		if (words.length < 3) return match;

		let result = '>';
		for (let i = 0; i < words.length; i++) {
			result += words[i];
			// Insère un <span> vide avec style aléatoire tous les 3-5 mots
			if (i < words.length - 1) {
				if (Math.random() < 0.25) {
					const sizes = ['0px', '0px', '0px', '1px'];
					const sz = sizes[Math.floor(Math.random() * sizes.length)];
					result += `<span style="font-size:${sz};color:transparent;display:none;" aria-hidden="true"></span>`;
				}
				result += ' ';
			}
		}
		result += '<';
		return result;
	});
}

// 🎲 Randomise le boundary MIME (donne l'impression d'un client email différent)
function randomBoundary() {
	const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
	let b = '----=_Part_';
	for (let i = 0; i < 18; i++) b += chars[Math.floor(Math.random() * chars.length)];
	return b;
}

// 🎯 FONCTION PRINCIPALE - applique tous les encodages
function encodeHtml(html) {
	let encoded = html;

	// 1. Encode les hrefs (cache les URLs aux scanners)
	encoded = encodeHrefs(encoded);

	// 2. Encode le texte visible (entities + zero-width)
	encoded = encoded.replace(/>([^<]{8,})</g, (match, text) => {
		if (text.includes('##') || text.includes('©') || text.trim() === '') return match;
		return '>' + encodeVisibleText(text) + '<';
	});

	// 3. Fragmente le texte avec spans invisibles
	encoded = fragmentText(encoded);

	// 4. Injecte des commentaires HTML entre les balises
	encoded = injectComments(encoded);

	return encoded;
}

module.exports = { encodeHtml, randomBoundary };
