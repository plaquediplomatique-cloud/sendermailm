# 📧 SENDERMAIL - Email Sender avec Support Proxy

Un script Node.js pour envoyer des emails en masse avec support des proxies HTTP/HTTPS.

## 🚀 Installation

```bash
npm install
```

## ⚙️ Configuration

### 1. **config.js** - Configuration SMTP et Email
Modifiez les paramètres suivants:
- `host` - Serveur SMTP (ex: smtp.centrum.cz)
- `port` - Port SMTP (587 pour TLS, 465 pour SSL)
- `smtpUser` - Email SMTP
- `smtpPass` - Mot de passe SMTP
- `fromName` - Nom d'expéditeur
- `fromMail` - Email d'expéditeur
- `subject` - Sujet des emails
- `header` - Headers personnalisés
- `delay` - Délai entre les envois (en ms)

### 2. **ml.txt** - Liste des emails destinataires
Un email par ligne:
```
user1@example.com
user2@example.com
user3@example.com
```

### 3. **proxy.txt** - Liste des proxies (NOUVEAU)
Un proxy par ligne. Formats acceptés:

```
# Format simple (sans authentification)
192.168.1.1:8080
10.0.0.1:3128

# Format avec authentification (user:pass)
192.168.1.1:8080:admin:password123
proxy.example.com:8080:user:pass

# Format URL complet
http://admin:password123@192.168.1.1:8080
https://user:pass@proxy.example.com:8888
```

### 4. **letter.html** - Template d'email HTML
Variables dynamiques supportées:
- `##email##` - Email du destinataire
- `##ref##` - Référence unique (CHxxxxxx)
- `##date##` - Date actuelle (DD/MM/YYYY)
- `##time##` - Heure actuelle (HH:mm:ss)

Exemple:
```html
<html>
  <body>
    <p>Bonjour ##email##,</p>
    <p>Votre référence: ##ref##</p>
    <p>Envoyé le ##date## à ##time##</p>
  </body>
</html>
```

## ▶️ Utilisation

### Démarrer l'envoi:
```bash
npm start
```

ou

```bash
node main.js
```

## 📊 Fonctionnalités

✅ **Support des proxies** - Rotation automatique parmi les proxies disponibles
✅ **Authentification proxy** - Support des proxies avec user/pass
✅ **Rotation des proxies** - Bascule automatique entre proxies (un proxy par email)
✅ **Encodage anti-spam** - Encodage HTML pour éviter les filtres
✅ **Gestion d'erreurs** - Enregistrement des emails échoués dans `failed.txt`
✅ **Affichage détaillé** - Logs en couleurs avec informations du proxy utilisé
✅ **Variables dynamiques** - Personnalisation par email et référence unique
✅ **Délai configurable** - Évite les limitations de débit SMTP

## 🔧 Résolution de problèmes

### Pas de proxy.txt? 
Le script fonctionne sans proxy (connexion directe si proxy.txt n'existe pas)

### Erreurs de connexion SMTP?
- Vérifiez host/port/user/pass dans config.js
- Testez la connexion manuellement avec telnet

### Erreurs de proxy?
- Vérifiez le format du proxy (ip:port ou ip:port:user:pass)
- Testez la connexion au proxy
- Vérifiez les credentials du proxy

### Erreurs d'emails?
- Vérifiez le format des emails dans ml.txt
- Les emails échoués sont sauvegardés dans failed.txt
- Relancez le script après correction

## 📝 Exemple complet

**config.js:**
```javascript
host: "smtp.gmail.com",
port: 587,
smtpUser: "myaccount@gmail.com",
smtpPass: "app-password",
fromName: "Support",
fromMail: "myaccount@gmail.com"
```

**proxy.txt:**
```
192.168.1.100:8080:admin:pass123
10.0.0.1:3128:user:password
```

**ml.txt:**
```
alice@example.com
bob@example.com
charlie@example.com
```

**Résultat:**
- alice@example.com → envoyé via 192.168.1.100:8080
- bob@example.com → envoyé via 10.0.0.1:3128
- charlie@example.com → envoyé via 192.168.1.100:8080 (rotation)

## 📜 License

MIT
