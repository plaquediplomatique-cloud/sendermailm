"use strict";

const colors = require("colors");
const figlet = require("figlet");
const nodemailer = require("nodemailer");
const fs = require("fs");
const moment = require("moment");
const yesno = require("yesno");
const config = require("./config.js");

// 📩 LISTE EMAILS
const listRaw = fs.readFileSync(config.send.list || "ml.txt").toString().split("\n");
const list = listRaw.map(line => {
	const parts = line.trim().split(":");
	return {
		email: parts[0] || "",
		nom: parts[1] || "",
		prenom: parts[2] || ""
	};
}).filter(item => item.email !== "");

const failedListFile = config.send.failedList || "failed.txt";
const letter = fs.readFileSync(config.send.letter, "utf-8");

// 📧 Read SMTP accounts from smtp.txt if concurrency enabled
let smtpAccounts = [];
if (config.send.enableConcurrency) {
	try {
		const smtpFile = fs.readFileSync("smtp.txt", "utf-8");
		smtpAccounts = smtpFile.split("\n")
			.map(line => line.trim())
			.filter(line => line && !line.startsWith("#"))
			.map(line => {
				let user, pass;
				if (line.includes(":")) {
					[user, pass] = line.split(":");
				} else if (line.includes(",")) {
					[user, pass] = line.split(",");
				}
				if (!user || !pass) return null;
				return { user: user.trim(), pass: pass.trim() };
			})
			.filter(account => account !== null);

		if (smtpAccounts.length === 0) {
			console.log(colors.red("❌ No SMTP accounts found in smtp.txt, disabling concurrency"));
			config.send.enableConcurrency = false;
		}
	} catch (e) {
		console.log(colors.red("❌ Error reading smtp.txt, disabling concurrency"));
		config.send.enableConcurrency = false;
	}
}

console.log("\n");
console.log(colors.rainbow(figlet.textSync("MAILER AWS")));
console.log("\n");

// 🔧 RANDOM STRING
function randomstring(type, length) {
	const seed = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	let result = "";
	for (let i = 0; i < length; i++) {
		result += seed.charAt(Math.floor(Math.random() * seed.length));
	}
	return result;
}

// 🔧 REF UNIQUE
function generateRef(prefix) {
	const ALPHA  = "ABCDEFGHJKLMNPQRSTUVWXYZ";
	const NUM    = "0123456789";
	const ALNUM  = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjklmnpqrstuvwxyz0123456789";

	const rand = (pool, len) =>
		Array.from({ length: len }, () => pool[Math.floor(Math.random() * pool.length)]).join('');

	const p1 = rand(ALPHA, 2) + rand(NUM, 1);
	const ts = (Date.now() + Math.floor(Math.random() * 999999)).toString(36).toUpperCase();
	const b1 = rand(ALNUM, 8);
	const b2 = rand(ALNUM, 6);
	const b3 = rand(NUM, 4) + rand(ALPHA, 4) + rand(NUM, 4);
	const ck = Math.floor(Math.random() * 0xFFFFFF).toString(16).toUpperCase().padStart(6, '0');

	return `${p1}-${ts}-${b1}-${b2}-${b3}-${ck}`;
}

// 🔧 TAGS
function tagsgen(input, email, nom, prenom, refNumber) {
	return input
		.replace(/##email##/g, email)
		.replace(/##nom##/g, nom || "")
		.replace(/##prenom##/g, prenom || "")
		.replace(/##ref##/g, refNumber || "");
}

// 🔌 Create transporter with connection pooling (reuse connections)
function createTransporter(smtpAccount) {
	const account = smtpAccount || { user: config.send.smtpUser, pass: config.send.smtpPass };

	const smtp = {
		host: config.send.host,
		port: config.send.port,
		secure: false,
		auth: {
			user: account.user,
			pass: account.pass
		},
		tls: {
			rejectUnauthorized: false
		},
		maxConnections: 1,
		maxMessages: Infinity,
		rateDelta: 1000,
		rateLimit: 10
	};

	return nodemailer.createTransport(smtp);
}

// 🚀 SEND FUNCTION (uses transporter from batch, reuses connection)
function sending(transporter, email, nom, prenom, no, total, smtpAccount) {
	return new Promise((resolve) => {
		const refNumber = generateRef(config.send.refPrefix || "REF");

		// Use SMTP account email if concurrency enabled, otherwise use config
		const fromEmail = smtpAccount ? smtpAccount.user : config.send.fromMail;

		const message = {
			from: `${config.send.fromName} <${fromEmail}>`,
			to: email,
			subject: tagsgen(config.send.subject, email, nom, prenom, refNumber),
			html: tagsgen(letter, email, nom, prenom, refNumber)
		};

		transporter.sendMail(message, (error, info) => {
			if (error) {
				fs.appendFileSync(failedListFile, email + "\n");

				const errorMsg = error.message.toLowerCase();
				const isQuotaError = errorMsg.includes('maximum') || errorMsg.includes('554') ||
									 errorMsg.includes('quota') || errorMsg.includes('rate');

				console.log(
					colors.red(`[${no + 1}/${total}] ❌ ${email} -> ${error.message}`)
				);

				if (isQuotaError && smtpAccount) {
					console.log(colors.yellow(`   ⚠️  Compte ${smtpAccount.user} - QUOTA ATTEINT, DÉSACTIVÉ`));
					resolve({ success: false, disabled: true, account: smtpAccount.user });
				} else {
					resolve({ success: false, disabled: false });
				}
			} else {
				console.log(
					colors.green(`[${no + 1}/${total}] ✅ ${email}`)
				);
				resolve({ success: true, disabled: false });
			}
		});
	});
}

// ▶ START
async function startsend() {

	console.log(colors.cyan(`Total: ${list.length}`));
	if (config.send.enableConcurrency) {
		console.log(colors.green(`⚡ Concurrency enabled - ${smtpAccounts.length} SMTP accounts (${Math.ceil(list.length / smtpAccounts.length)} batches)`));
	}

	const confirm = await yesno({
		question: "Start sending? (y/n)"
	});

	if (!confirm) {
		console.log("Cancelled");
		process.exit();
	}

	if (!config.send.enableConcurrency) {
		// Normal mode: send one by one with delay (single transporter, reused)
		const transporter = createTransporter(null);
		let i = 0;

		for (const item of list) {
			await sending(transporter, item.email, item.nom, item.prenom, i, list.length, null);
			i++;

			if (i < list.length) {
				await new Promise(resolve => setTimeout(resolve, config.send.delay));
			}
		}

		transporter.close();
	} else {
		// Concurrency mode: send by batches with disabled account handling
		const transporters = {}; // Cache for reusable transporters
		let disabledAccounts = new Set(); // Track disabled accounts
		let availableAccounts = [...smtpAccounts]; // Working copy

		for (let batchIndex = 0; batchIndex < list.length; batchIndex += availableAccounts.length) {
			const batch = list.slice(batchIndex, batchIndex + availableAccounts.length);
			const promises = [];

			// Send this batch's emails all at the same time
			batch.forEach((item, indexInBatch) => {
				const globalIndex = batchIndex + indexInBatch;
				const smtpAccount = availableAccounts[indexInBatch];
				const accountKey = smtpAccount.user;

				// Create transporter once per account and reuse it
				if (!transporters[accountKey]) {
					transporters[accountKey] = createTransporter(smtpAccount);
				}

				// sending() now returns result with disabled status
				const promise = sending(transporters[accountKey], item.email, item.nom, item.prenom, globalIndex, list.length, smtpAccount)
					.then(result => {
						// If account hit quota, disable it
						if (result.disabled && result.account) {
							disabledAccounts.add(result.account);
							// Remove from available accounts
							availableAccounts = availableAccounts.filter(acc => acc.user !== result.account);
						}
						return result;
					});
				promises.push(promise);
			});

			// Wait for all emails in this batch to be sent
			await Promise.all(promises);

			// Stop if all accounts are disabled
			if (availableAccounts.length === 0) {
				console.log(colors.red("\n❌ Tous les comptes SMTP sont désactivés, arrêt"));
				break;
			}

			// Delay before next batch (if not last batch)
			if (batchIndex + availableAccounts.length < list.length) {
				await new Promise(resolve => setTimeout(resolve, config.send.delay));
			}
		}

		// Close all transporters
		Object.values(transporters).forEach(t => t.close());
	}
}

startsend();